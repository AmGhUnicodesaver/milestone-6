# The following imports are necessary
import rclpy
from rclpy.node import Node

# Replace the following import with the interface this node is using
from example_interfaces.srv import AddTwoInts

# For example, service message type Kill from the package turtlesim would be imported as follows:
#
# from turtlesim.srv import Kill

# Furthermore, you can import here any Python module you plan to use in this node


# The class name is up to you
class MyClassName(Node):
    def __init__(self):
        super().__init__("default_node_name_up_to_you")
        # Service servers are created using interface type, service name and callback function
        self.service = self.create_service(
            AddTwoInts, "service_name", self.service_callback
        )

    # Service callback will be called when the server receives a request
    # Note that the request and response variables are already created and just need to be filled with data
    def service_callback(self, request, response):
        response.sum = request.a + request.b
        # Logger displays formatted text in the console, useful for simple debugging
        self.get_logger().info(f"Incoming request\na: {request.a}, b: {request.b}")

        # The response to be returned is part of the interface (the part below three dashes when using interface show <name_of_interface> in CLI or in the .srv file)
        return response


# The code below runs the node and should be left as is
def main(args=None):
    rclpy.init(args=args)

    node = MyClassName()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == "__main__":
    main()
